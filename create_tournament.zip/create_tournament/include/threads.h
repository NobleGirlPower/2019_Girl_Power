void thread_valve();
void thread_startpos();
void thread_pre_valve();
void thread_ready_valve();